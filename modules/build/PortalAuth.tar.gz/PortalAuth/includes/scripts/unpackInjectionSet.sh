#!/bin/sh

cd /pineapple/modules/PortalAuth/includes/scripts/injects/;
tar -xzf $1;
rm -rf $1;
