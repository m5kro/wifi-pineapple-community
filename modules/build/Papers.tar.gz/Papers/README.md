# Papers
This is a module for the WiFi Pineaple NANO and TETRA that allows you to create and manage TLS/SSL certificates with ease.  It will also update the nginx configuration on the Pineapple to use/remove SSL automatically.

Check out the [tutorial video](https://www.youtube.com/watch?v=XQ6qmouMtS4) for Papers.
