<?php
header("Cache-Control: no-cache, must-revalidate");
header("Expires: Sat, 30 Sep 1998 03:13:37");
?>

<HTML>
<head>
<title>Never gonna give you up!</title> 
</head> 
<body bgcolor="black">
<center>
<img src="Rolls/RickRoll/asset/gif.gif">	
</center>

 <audio loop autoplay>
 	 <source src="Rolls/RickRoll/asset/song.mp3" type="audio/mpeg">
  	 <source src="Rolls/RickRoll/asset/song.ogg" type="audio/ogg">
 </audio>


</body>
</HTML>
