<HTML>
<head>
	<!-- RCMRoll originally made by petertfm -- Modified by Foxtrot -->
<title>RAINBOW CHICKEN MAN AAAHHHH!!</title> 
</head> 
<body bgcolor="black">
<center>
	<img src="Rolls/RCM/asset/gif.gif">

 <audio loop autoplay>
 	 <source src="Rolls/RCM/asset/song.mp3" type="audio/mpeg">
  	 <source src="Rolls/RCM/asset/song.ogg" type="audio/ogg">
 </audio>
 </center>

</body>
</HTML>
